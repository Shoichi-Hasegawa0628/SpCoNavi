# 正誤表
## 第1版第1刷
|   page  |  誤  |  正  |
| ------- | ---- | ---- |
|  p.120  | 無し | ![cv_bridgeを利用したROSとOpenCVの連携の概念図](./.img/cv_bridge.png "cv_bridgeを利用したROSとOpenCVの連携の概念図")<br> cv_bridgeを利用したROSとOpenCVの連携の概念図|
