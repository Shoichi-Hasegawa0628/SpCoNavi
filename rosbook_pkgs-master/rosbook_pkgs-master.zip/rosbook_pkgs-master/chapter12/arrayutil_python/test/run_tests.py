#!/usr/bin/env python
import rostest
rostest.rosrun('arrayutil_python', 'arrayutil_python_test', 'arrayutil_python_testcases.ArrayUtilTestSuite')
