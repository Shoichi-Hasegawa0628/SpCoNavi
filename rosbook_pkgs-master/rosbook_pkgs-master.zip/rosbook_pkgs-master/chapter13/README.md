# Travis CI exercise
See the following reporitories for Travis CI exercise, which include Travis CI related files (e.g. `.travis.yml`).

## pluginlib_arrayutil_ci (Based on pluginlib_arrayutil)

https://github.com/Nishida-Lab/pluginlib_arrayutil_ci

## pluginlib_arrayutil_client_ci (Based on pluginlib_arrayutil_client)

https://github.com/Nishida-Lab/pluginlib_arrayutil_client_ci

 
# 正誤表
## 第1版第1刷
|   page  |  誤  |  正  |
| ------- | ---- | ---- |
|  p.251   | ...大きな特長です． | ...大きな特長です<sup>&dagger;</sup>． |
|  p.251   | 注釈部 | <sup>&dagger;</sup>ROSのパッケージ管理を統括する「Build Farm」では「Jenkins」を利用することで，CIに加えバイナリパッケージの配布や解析等まで自動で行われています． |
