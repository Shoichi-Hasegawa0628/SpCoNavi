# pluginlib_arrayutil_client
ROS pluginlib example of arrayunit: Client side
