# 正誤表
## 第1版第1刷
|   page  |  誤  |  正  |
| ------- | ---- | ---- |
|  p.95   | https://github.com/ros-controls/ros_controllers/blob/kinetic-devel/diff_drive_controller/include/diff_drive_controller/diff_drive_controller.h#66  | https://github.com/ros-controls/ros_controllers/blob/kinetic-devel/diff_drive_controller/include/diff_drive_controller/diff_drive_controller.h |
